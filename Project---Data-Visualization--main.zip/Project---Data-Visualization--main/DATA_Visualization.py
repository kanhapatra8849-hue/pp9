
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

class SalesDataAnalyzer:
    def __init__(self):
        self.data = pd.DataFrame()
        self.last_plot = None

    def __del__(self):
        pass

    def load_data(self,file_path):
        try:
            self.data = pd.read_csv(file_path)

            if "Date" in self.data.columns:
                self.data["Date"] = pd.to_datetime(self.data["Date"],errors="coerce")

            for column in ["Sales","Profit","Quantity","Discount"]:
                if column in self.data.columns:
                    self.data[column] = pd.to_numeric(self.data[column],errors="coerce")

            print("Dataset loaded successfully!")

        except FileNotFoundError:
            print("File not found.")
        except Exception as e:
            print("Error:",e)

    def explore_data(self):
        if self.data.empty:
            print("\nPlease load a dataset first.")
            return

        print("\n== Explore Data ==")
        print("1. Display the first 5 rows")
        print("2. Display the last 5 rows")
        print("3. Display column names")
        print("4. Display data types")
        print("5. Display basic info")

        choice = input("Enter your choice: ")

        if choice == "1":
            print(self.data.head())
        elif choice == "2":
            print(self.data.tail())
        elif choice == "3":
            print(self.data.columns.tolist())
        elif choice == "4":
            print(self.data.dtypes)
        elif choice == "5":
            self.data.info()
        else:
            print("Invalid choice.")

    def dataframe_operations(self):
        if self.data.empty:
            print("\nPlease load a dataset first.")
            return

        print("\n== DataFrame Operations ==")
        print("1. Combine DataFrames")
        print("2. Split DataFrame")
        print("3. Search data")
        print("4. Sort data")
        print("5. Filter data")
        print("6. Aggregate functions")
        print("7. Create pivot table")
        print("8. GroupBy and Transform")
        print("9. Re-index and alter labels")

        choice = input("Enter your choice: ")

        if choice == "1":
            path = input("Enter second CSV file path: ")

            try:
                second_data = pd.read_csv(path)
                self.data = pd.concat([self.data,second_data],ignore_index=True)
                print("DataFrames combined successfully!")
            except Exception as e:
                print("Error:",e)

        elif choice == "2":
            if "Region" not in self.data.columns:
                print("Region column not found.")
                return

            print("\nData split by Region:")

            for region,group in self.data.groupby("Region"):
                print(region)
                print(group.head())
                print()

        elif choice == "3":
            column = input("Enter column name: ")
            value = input("Enter value to search: ")

            if column in self.data.columns:
                result = self.data[self.data[column].astype(str).str.contains(value,case=False,na=False)]
                print(result)
            else:
                print("Column not found.")

        elif choice == "4":
            column = input("Enter column name to sort: ")

            if column in self.data.columns:
                result = self.data.sort_values(column,ascending=False)
                print(result)
            else:
                print("Column not found.")

        elif choice == "5":
            column = input("Enter column name: ")
            value = input("Enter value: ")

            if column in self.data.columns:
                result = self.data[self.data[column].astype(str).str.lower() == value.lower()]
                print(result)
            else:
                print("Column not found.")

        elif choice == "6":
            if "Sales" not in self.data.columns:
                print("Sales column not found.")
                return

            print("\nTotal Sales:",self.data["Sales"].sum())
            print("Average Sales:",self.data["Sales"].mean())
            print("Number of Sales:",self.data["Sales"].count())

        elif choice == "7":
            required = ["Region","Product","Sales","Profit"]

            if all(column in self.data.columns for column in required):
                pivot = pd.pivot_table(
                    self.data,
                    index="Region",
                    columns="Product",
                    values=["Sales","Profit"],
                    aggfunc="sum",
                    fill_value=0
                )

                print("\n== Pivot Table ==")
                print(pivot)
            else:
                print("Required columns are missing.")

        elif choice == "8":
            if "Region" not in self.data.columns:
                print("Region column not found.")
                return

            self.data["Region_Total_Sales"] = self.data.groupby("Region")["Sales"].transform("sum")

            print(self.data[["Region","Sales","Region_Total_Sales"]].head())

        elif choice == "9":
            demo = self.data.head(5).copy()
            demo.index = ["Order-1","Order-2","Order-3","Order-4","Order-5"][:len(demo)]

            if "Sales" in demo.columns:
                demo = demo.rename(columns={"Sales":"Sales_Amount"})

            print("\n== Re-index and Alter Labels ==")
            print(demo)

        else:
            print("Invalid choice.")

    def missing_data(self):
        if self.data.empty:
            print("\nPlease load a dataset first.")
            return

        print("\n== Handle Missing Data ==")
        print("1. Display rows with missing values")
        print("2. Fill missing values with mean")
        print("3. Drop rows with missing values")
        print("4. Replace missing values with a specific value")

        choice = input("Enter your choice: ")

        if choice == "1":
            missing = self.data[self.data.isnull().any(axis=1)]

            if missing.empty:
                print("No missing values found in the dataset!")
            else:
                print(missing)

        elif choice == "2":
            numbers = self.data.select_dtypes(include=np.number).columns

            for column in numbers:
                self.data[column] = self.data[column].fillna(self.data[column].mean())

            print("Missing numeric values filled with mean.")

        elif choice == "3":
            self.data.dropna(inplace=True)
            print("Rows with missing values removed.")

        elif choice == "4":
            value = input("Enter value: ")
            self.data.fillna(value,inplace=True)
            print("Missing values replaced successfully.")

        else:
            print("Invalid choice.")

    def mathematical_operations(self):
        if self.data.empty:
            print("\nPlease load a dataset first.")
            return

        if "Sales" not in self.data.columns:
            print("Sales column not found.")
            return

        sales = self.data["Sales"].dropna().to_numpy()

        print("\n== NumPy Array Operations ==")
        print("NumPy array:")
        print(sales)

        if len(sales) > 0:
            print("\nFirst element:")
            print(sales[0])

            print("\nLast element:")
            print(sales[-1])

            print("\nFirst 5 elements:")
            print(sales[:5])

            print("\nEvery second element:")
            print(sales[::2])

            print("\nSales + 100:")
            print(sales[:5] + 100)

            print("\nSales * 2:")
            print(sales[:5] * 2)

            print("\nTotal Sales:",np.sum(sales))
            print("Average Sales:",np.mean(sales))
            print("Maximum Sales:",np.max(sales))
            print("Minimum Sales:",np.min(sales))

    def statistical_analysis(self):
        if self.data.empty:
            print("\nPlease load a dataset first.")
            return

        numbers = self.data.select_dtypes(include=np.number)

        print("\n== Statistical Analysis ==")

        print("\nStandard Deviation:")
        print(numbers.std())

        print("\nVariance:")
        print(numbers.var())

        print("\n25%, 50%, 75% Quantiles:")
        print(numbers.quantile([0.25,0.50,0.75]))

        print("\nDescribe:")
        print(numbers.describe())

    def visualization(self):
        if self.data.empty:
            print("\nPlease load a dataset first.")
            return

        print("\n== Data Visualization ==")
        print("1. Bar Plot")
        print("2. Line Plot")
        print("3. Scatter Plot")
        print("4. Pie Chart")
        print("5. Correlation Heatmap")

        choice = input("Enter your choice: ")

        if choice == "1":
            column = input("Enter column name: ")

            if column not in self.data.columns:
                print("Column not found.")
                return

            values = self.data[column].value_counts()

            plt.figure(figsize=(8,5))
            values.plot(kind="bar")
            plt.title("Bar Plot")
            plt.xlabel(column)
            plt.ylabel("Count")
            plt.tight_layout()

            self.last_plot = plt

            print("Generating bar plot...")
            plt.show()
            print("Bar plot displayed successfully!")

        elif choice == "2":
            x = input("Enter x-axis column name: ")
            y = input("Enter y-axis column name: ")

            if x not in self.data.columns or y not in self.data.columns:
                print("Column not found.")
                return

            plt.figure(figsize=(9,5))
            plt.plot(self.data[x],self.data[y],marker="o")
            plt.title("Line Plot")
            plt.xlabel(x)
            plt.ylabel(y)
            plt.xticks(rotation=45)
            plt.tight_layout()

            self.last_plot = plt

            print("Generating line plot...")
            plt.show()
            print("Line plot displayed successfully!")

        elif choice == "3":
            print("\n== Scatter Plot ==")

            x = input("Enter x-axis column name: ")
            y = input("Enter y-axis column name: ")

            if x not in self.data.columns or y not in self.data.columns:
                print("Column not found.")
                return

            print("Generating scatter plot...")

            sns.scatterplot(data=self.data,x=x,y=y)

            plt.title(x + " vs " + y)
            plt.xlabel(x)
            plt.ylabel(y)
            plt.tight_layout()

            self.last_plot = plt

            plt.show()

            print("Scatter plot displayed successfully!")

        elif choice == "4":
            column = input("Enter column name: ")

            if column not in self.data.columns:
                print("Column not found.")
                return

            values = self.data[column].value_counts()

            plt.figure(figsize=(7,7))
            plt.pie(values,labels=values.index,autopct="%1.1f%%")
            plt.title("Pie Chart")
            plt.tight_layout()

            self.last_plot = plt

            print("Generating pie chart...")
            plt.show()
            print("Pie chart displayed successfully!")

        elif choice == "5":
            numbers = self.data.select_dtypes(include=np.number)

            if len(numbers.columns) < 2:
                print("Need at least two numeric columns.")
                return

            plt.figure(figsize=(8,6))
            sns.heatmap(numbers.corr(),annot=True,fmt=".2f")
            plt.title("Correlation Heatmap")
            plt.tight_layout()

            self.last_plot = plt

            print("Generating correlation heatmap...")
            plt.show()
            print("Heatmap displayed successfully!")

        else:
            print("Invalid choice.")

    def save_visualization(self):
        if self.last_plot is None:
            print("\nPlease create a visualization first.")
            return

        print("\n== Save Visualization ==")

        filename = input("Enter file name to save the plot (e.g., scatter_plot.png): ")

        self.last_plot.savefig(filename)

        print("Visualization saved as",filename,"successfully!")


class AdvancedSalesAnalyzer(SalesDataAnalyzer):
    def __init__(self):
        super().__init__()

    def top_products(self):
        if self.data.empty:
            print("\nPlease load a dataset first.")
            return

        if "Product" not in self.data.columns:
            print("Product column not found.")
            return

        result = self.data.groupby("Product")["Sales"].sum().sort_values(ascending=False).head(5)

        print("\n== Top 5 Products ==")
        print(result)


def menu():
    print("\n========== Data Analysis & Visualization Program ==========")
    print("Please select an option:")
    print("1. Load Dataset")
    print("2. Explore Data")
    print("3. Perform DataFrame Operations")
    print("4. Handle Missing Data")
    print("5. Generate Descriptive Statistics")
    print("6. Data Visualization")
    print("7. Save Visualization")
    print("8. Exit")
    print("===========================================================")


def main():
    analyzer = AdvancedSalesAnalyzer()

    while True:
        menu()

        choice = input("Enter your choice: ")

        if choice == "1":
            print("\n== Load Dataset ==")
            path = input("Enter the path of the dataset (CSV file): ")
            analyzer.load_data(path)

        elif choice == "2":
            analyzer.explore_data()

        elif choice == "3":
            analyzer.dataframe_operations()

        elif choice == "4":
            analyzer.missing_data()

        elif choice == "5":
            analyzer.statistical_analysis()

        elif choice == "6":
            analyzer.visualization()

        elif choice == "7":
            analyzer.save_visualization()

        elif choice == "8":
            print("\nExiting the program. Goodbye!")
            break

        else:
            print("\nInvalid choice. Please select 1-8.")


if __name__ == "__main__":
    main()