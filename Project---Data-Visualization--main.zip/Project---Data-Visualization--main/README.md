# Project---Data-Analyzer-


A beginner-friendly Python project for loading, analyzing, processing, and visualizing sales data from CSV files.

## Features

### 1. Load Dataset

* Loads sales data from a CSV file.
* Automatically converts the `Date` column to date format.
* Converts `Sales`, `Profit`, `Quantity`, and `Discount` columns to numeric values.

### 2. Explore Data

You can:

* Display the first 5 rows.
* Display the last 5 rows.
* View column names.
* View data types.
* View basic dataset information.

### 3. DataFrame Operations

The program provides several Pandas operations:

* Combine two CSV datasets.
* Split data by Region.
* Search for specific data.
* Sort data by a column.
* Filter data.
* Calculate total, average, and number of sales.
* Create pivot tables.
* Use GroupBy and Transform.
* Re-index rows and change column labels.

### 4. Handle Missing Data

The program can:

* Display rows containing missing values.
* Fill missing numeric values with the mean.
* Remove rows containing missing values.
* Replace missing values with a specific value.

### 5. Mathematical Operations

NumPy is used to perform operations on the Sales column, including:

* Array slicing.
* Accessing first and last elements.
* Selecting every second element.
* Adding values to sales.
* Multiplying sales values.
* Calculating sum, average, maximum, and minimum.

### 6. Statistical Analysis

The program calculates:

* Standard deviation.
* Variance.
* Quantiles.
* Descriptive statistics.

### 7. Data Visualization

The program can create:

* Bar plots.
* Line plots.
* Scatter plots.
* Pie charts.
* Correlation heatmaps.

### 8. Save Visualization

Created plots can be saved as image files such as PNG.

## Technologies Used

* Python
* Pandas
* NumPy
* Matplotlib
* Seaborn

## Requirements

Install the required libraries using:

```bash
pip install pandas numpy matplotlib seaborn
```

## How to Run

1. Install Python.
2. Install the required libraries.
3. Save the program as a Python file, for example:

```text
sales_analyzer.py
```

4. Run the program:

```bash
python sales_analyzer.py
```

5. Select an option from the menu.
6. Load your CSV dataset when requested.

## Dataset

The program works with CSV files.

For the best results, the dataset can contain columns such as:

```text
Date
Region
Product
Sales
Profit
Quantity
Discount
```

The program checks whether columns exist before performing operations, so some features can still work with datasets that have fewer columns.

## Example Menu

```text
========== Data Analysis & Visualization Program ==========
Please select an option:
1. Load Dataset
2. Explore Data
3. Perform DataFrame Operations
4. Handle Missing Data
5. Generate Descriptive Statistics
6. Data Visualization
7. Save Visualization
8. Exit
===========================================================
```

## Project Structure

```text
project-folder/
│
├── sales_analyzer.py
├── dataset.csv
└── README.md
```

## Concepts Demonstrated

This project demonstrates several important Python and data analysis concepts:

* Classes and objects
* Inheritance
* Constructors
* Pandas DataFrames
* NumPy arrays
* Data cleaning
* GroupBy operations
* Pivot tables
* Statistical analysis
* Data visualization
* File handling
* Exception handling
* User input
* Menu-driven programming

## Purpose

This project is designed for beginners who want to practice Python programming together with Pandas, NumPy, Matplotlib, and Seaborn.

It provides a simple menu-driven system for performing common sales data analysis tasks.
